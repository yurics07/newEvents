package com.senai.eventsmanager.enums;

public enum EventoEnum {
    CONGRESSO,
    TREINAMENTO,
    WORKSHOP,
    IMERSÃO,
    REUNIÃO,
    HACKATON,
    STARTUP
}
